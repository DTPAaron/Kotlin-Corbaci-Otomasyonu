package com.harunaltun.vizeuygulama

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_besinci.*
import kotlinx.android.synthetic.main.activity_dorduncu.*

class besinci : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_besinci)
        var alinancorbaismi=intent.getStringExtra("corbaaktar")
        var aciorani=intent.getStringExtra("aciorani")
        var tuzorani=intent.getStringExtra("tuzorani")
        var istek=intent.getStringExtra("istek")
        var sarimsak=intent.getStringExtra("sarımsak")
        var dil=intent.getStringExtra("dil")
        var beyin=intent.getStringExtra("beyin")
        var kıtır=intent.getStringExtra("kıtır")
        var kaşar=intent.getStringExtra("kaşar")
        var sirke=intent.getStringExtra("sirke")
        var limon=intent.getStringExtra("limon")
        var terbiye=intent.getStringExtra("terbiye")
        var nane=intent.getStringExtra("nane")
        var yağ=intent.getStringExtra("yağ")
        var tozbiber=intent.getStringExtra("tozbiber")
        var krema=intent.getStringExtra("krema")
        if(sarimsak==null){
            sarimsak=""
        }else {
            sarimsak = "sarımsak,"
        }
        if(dil==null){
            dil=""
        }else {
            dil = "dil,"
        }
        if(beyin==null){
            beyin=""
        }else {
            beyin = "beyin,"
        }
        if(kıtır==null){
            kıtır=""
        }else {
            kıtır = "kıtır,"
        }
        if(kaşar==null){
            kaşar=""
        }else {
            kaşar = "kaşar,"
        }
        if(sirke==null){
            sirke=""
        }else {
            sirke = "sirke,"
        }
        if(limon==null){
            limon=""
        }else {
            limon = "limon,"
        }
        if(terbiye==null){
            terbiye=""
        }else {
            terbiye = "terbiye,"
        }
        if(nane==null){
            nane=""
        }else {
            nane = "nane,"
        }
        if(yağ==null){
            yağ=""
        }else {
            yağ = "yağ,"
        }
        if(tozbiber==null){
            tozbiber=""
        }else {
            tozbiber = "tozbiber,"
        }
        if(krema==null){
            krema=""
        }else {
            krema = "krema,"
        }
        corbatuzaci.text="Bir $alinancorbaismi Çeeek,$tuzorani ve $aciorani olsun"
        corbaici.text="$sarimsak$terbiye$krema$kıtır$nane$beyin$yağ$limon$dil$kaşar$sirke$tozbiber"
        if (corbaici.text==""){
            textView15.visibility=View.INVISIBLE
            textView17.visibility=View.INVISIBLE
        }
        if (istek==""){
            ekstra.visibility=View.INVISIBLE
        }else{
            ekstra.text="Ekstra İstek: $istek"
        }
        var yenisiparis=textView9
        object: CountDownTimer(10000,700){
            override fun onTick(p0: Long) {
                    yenisiparis.visibility=View.INVISIBLE
                Handler().postDelayed({
                    yenisiparis.visibility=View.VISIBLE
                },100)
            }

            override fun onFinish() {
                yenisiparis.visibility=View.VISIBLE
            }

        }.start()

        yenisiparis.setOnClickListener{
            var gecis=Intent(applicationContext,ucuncu::class.java)
            startActivity(gecis)
            finish()
        }
        var cikis=imageView6
        cikis.setOnClickListener{
            val uyari= AlertDialog.Builder(this@besinci)
            uyari.setTitle("Çıkış")
            uyari.setMessage("Çıkmak İstediğinize Emin misiniz?")
            uyari.setCancelable(false)
            uyari.setIcon(R.drawable.xlogo)
            uyari.setNegativeButton("Hayır"){
                DialogInterface,i->
            }
            uyari.setPositiveButton("Evet"){
                DialogInterface,i->
                System.exit(0)
            }
            uyari.create().show()
        }
    }
}