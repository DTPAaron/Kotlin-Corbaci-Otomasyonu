package com.harunaltun.vizeuygulama

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_dorduncu.*

class dorduncu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dorduncu)
        var corbaismi=corbaismi
        var alinancorbaismi=intent.getStringExtra("isim")
        var corbaaktar=alinancorbaismi
        corbaismi.text="$alinancorbaismi Çorbası"
        if (alinancorbaismi=="Ezogelin"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
            kıtır.visibility=View.VISIBLE
        }else if (alinancorbaismi=="Düğün"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
            kıtır.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Mercimek"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
            kıtır.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Brokoli"){
            krema.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Kelle Paça"){

            dil.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            sirke.visibility=View.VISIBLE
            sarımsak.visibility=View.VISIBLE
            beyin.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Yayla"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
            kıtır.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Şehriye"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Domates"){

            nane.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
            kıtır.visibility=View.VISIBLE
            kaşar.visibility=View.VISIBLE
            terbiye.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Tarhana"){

            yağ.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Mantar"){
            krema.visibility=View.VISIBLE
        }else if(alinancorbaismi=="İşkembe"){
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
            sirke.visibility=View.VISIBLE
            sarımsak.visibility=View.VISIBLE
            tozbiber.visibility=View.VISIBLE
        }else if(alinancorbaismi=="Tavuk"){
            krema.visibility=View.VISIBLE
            yağ.visibility=View.VISIBLE
            limon.visibility=View.VISIBLE
        }
            var tuz="Tuzsuz"
        tuzoranı.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p1==0){
                    tuz="Tuzsuz"
                }else if (p1==1){
                    tuz="Orta Tuzlu"
                }else if (p1==2){
                    val uyari= AlertDialog.Builder(this@dorduncu)
                    uyari.setTitle("Uyarı!")
                    uyari.setMessage("Bu kadar tuz istediğinize emin misiniz?")
                    uyari.setIcon(R.drawable.tuzlogo)
                    uyari.setCancelable(false)
                    uyari.setPositiveButton("Evet"){
                        DialogInterface,i->
                        tuz="Bol Tuzlu"
                        Toast.makeText(applicationContext,"Bol Tuzlu Çorba",Toast.LENGTH_LONG).show()
                    }
                    uyari.setNegativeButton("Hayır"){
                        DialogInterface,i->
                        tuz="Orta Tuzlu"
                        tuzoranı.progress=1
                    }
                    uyari.create().show()
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }
        })
        var aci="Acısız"
        acıoranı.setOnSeekBarChangeListener(object :SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p1==0){
                    aci="Acısız"
                }else if (p1==1){
                    aci="Orta Acılı"
                }else if(p1==2){
                    val uyari=AlertDialog.Builder(this@dorduncu)
                    uyari.setTitle("Uyarı!")
                    uyari.setMessage("Bu kadar acı istediğinize emin misiniz?")
                    uyari.setIcon(R.drawable.acilogo)
                    uyari.setCancelable(false)
                    uyari.setPositiveButton("Evet"){
                        DialogInterface,i->
                        aci="Bol Acılı"
                        Toast.makeText(applicationContext,"Bol Acılı Çorba",Toast.LENGTH_LONG).show()
                    }
                    uyari.setNegativeButton("Hayır"){
                        DialogInterface,i->
                        aci="Orta Acılı"
                        acıoranı.progress=1
                    }
                    uyari.create().show()
                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {

            }

        })
        var siparis=button
        siparis.setOnClickListener {
            val uyari=AlertDialog.Builder(this@dorduncu)
            uyari.setTitle("Siparişinizin Durumu")
            uyari.setIcon(R.drawable.logo)
            uyari.setCancelable(false)
            uyari.setMessage("Siparişiniz Hazırlanacak.Devam Etmek İstiyor musunuz?")
            uyari.setNeutralButton("Tekrar Kontrol Etmek İstiyorum"){
                DialogInterface,i->

            }
            uyari.setPositiveButton("Evet"){
                DialogInterface,i->
                var istekaktar=istek.text.toString()
                var gecis=Intent(applicationContext,besinci::class.java)
                gecis.putExtra("aciorani",aci)
                gecis.putExtra("tuzorani",tuz)
                gecis.putExtra("istek",istekaktar)
                gecis.putExtra("corbaaktar",corbaaktar)
                if (krema.isChecked){
                    gecis.putExtra( "krema",krema.text)
                }
                if (kıtır.isChecked){
                    gecis.putExtra("kıtır",kıtır.text)
                }
                if (nane.isChecked){
                    gecis.putExtra("nane",nane.text)
                }
                if (yağ.isChecked){
                    gecis.putExtra("yağ",yağ.text)
                }
                if (limon.isChecked){
                    gecis.putExtra("limon",limon.text)
                }
                if (tozbiber.isChecked){
                    gecis.putExtra("tozbiber",tozbiber.text)
                }
                if (kaşar.isChecked){
                    gecis.putExtra("kaşar",kaşar.text)
                }
                if (terbiye.isChecked){
                    gecis.putExtra("terbiye",krema.text)
                }
                if (beyin.isChecked){
                    gecis.putExtra("beyin",beyin.text)
                }
                if (dil.isChecked){
                    gecis.putExtra("dil",dil.text)
                }
                if (sarımsak.isChecked){
                    gecis.putExtra("sarımsak",sarımsak.text)
                }
                if (sirke.isChecked){
                    gecis.putExtra("sirke",sirke.text)
                }
                startActivity(gecis)
                finish()
            }
            uyari.create().show()
        }
}
}