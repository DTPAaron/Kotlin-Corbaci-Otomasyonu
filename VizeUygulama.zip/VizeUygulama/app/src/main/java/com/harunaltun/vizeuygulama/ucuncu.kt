package com.harunaltun.vizeuygulama

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_ucuncu.*
import kotlinx.android.synthetic.main.toast.view.*

class ucuncu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ucuncu)
        var corbachechk=checkBox
        corbachechk.setOnCheckedChangeListener { compoundButton, b ->
            if (b){
                Ezogelin.visibility=View.VISIBLE
                Düğün.visibility=View.VISIBLE
                Mercimek.visibility=View.VISIBLE
                Brokoli.visibility=View.VISIBLE
                KellePaça.visibility=View.VISIBLE
                Yayla.visibility=View.VISIBLE
                Şehriye.visibility=View.VISIBLE
                Domates.visibility=View.VISIBLE
                Tarhana.visibility=View.VISIBLE
                Mantar.visibility=View.VISIBLE
                İşkembe.visibility=View.VISIBLE
                Tavuk.visibility=View.VISIBLE
                devam.visibility=View.VISIBLE
            }
        }

    }
    fun devam(view: View){
        var isim=""
        if (Ezogelin.isChecked){
            isim="Ezogelin"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Düğün.isChecked){
            isim="Düğün"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Mercimek.isChecked){
            isim="Mercimek"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Brokoli.isChecked){
            isim="Brokoli"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (KellePaça.isChecked){
            isim="Kelle Paça"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Yayla.isChecked){
            isim="Yayla"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Şehriye.isChecked){
            isim="Şehriye"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (Domates.isChecked){
            isim="Domates"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)
        }else if (Tarhana.isChecked){
            isim="Tarhana"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)
        }else if (Mantar.isChecked){
            isim="Mantar"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else if (İşkembe.isChecked){
            isim="İşkembe"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)
            var gecis= Intent(applicationContext,dorduncu::class.java)
            gecis.putExtra("isim",isim)
            startActivity(gecis)
            finish()
        }else if (Tavuk.isChecked){
            isim="Tavuk"
            var toasttasarım=layoutInflater.inflate(R.layout.toast,null)
            var toastyazi=toasttasarım.findViewById<TextView>(R.id.textView8)
            toastyazi.text="${isim} Çorbası Güzel Seçim Lütfen Bekleyiniz"
            var toastozel=Toast(applicationContext)
            toastozel.view=toasttasarım
            toastozel.setGravity(Gravity.BOTTOM,0,0)
            toastozel.duration=Toast.LENGTH_LONG
            toastozel.show()
            Handler().postDelayed({
                var gecis= Intent(applicationContext,dorduncu::class.java)
                gecis.putExtra("isim",isim)
                startActivity(gecis)
                finish()
            },3000)

        }else{
            val uyari=AlertDialog.Builder(this)
            uyari.setTitle("Uyarı!")
            uyari.setMessage("Lütfen Seçiminizi Yapınız")
            uyari.setIcon(R.drawable.logo)
            uyari.setCancelable(false)
            uyari.setNeutralButton("Tekrar Dene"){
                DialogInterface,i->
            }
            uyari.create().show()
        }


    }
}


