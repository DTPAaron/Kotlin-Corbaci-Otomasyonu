package com.harunaltun.vizeuygulama

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_ikinci.*

class ikinci : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ikinci)
    }
    fun H(view: View){
        Hcheck.visibility=View.VISIBLE
    }
    fun A(view: View){
        if (Hcheck.visibility==View.VISIBLE){
                Acheck.visibility=View.VISIBLE
            }
    }
    fun R(view: View){
        if (Acheck.visibility==View.VISIBLE){
            Rcheck.visibility=View.VISIBLE
        }
    }
    fun U(view: View){
        if (Rcheck.visibility==View.VISIBLE){
            Ucheck.visibility=View.VISIBLE
        }
    }
    fun N(view: View){
        if (Ucheck.visibility==View.VISIBLE){
            Ncheck.visibility=View.VISIBLE
            progressBar.visibility=View.VISIBLE
            var gecis=Intent(applicationContext,ucuncu::class.java)
            startActivity(gecis)
            finish()
        }
    }
}