package com.harunaltun.vizeuygulama

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Handler().postDelayed({
            var gecis=Intent(applicationContext,ikinci::class.java)
            startActivity(gecis)
            finish()
        },5000)
        var i=1.0f
        object : CountDownTimer(700,1){
            override fun onTick(p0: Long) {
                    textView.setTextSize(i)
                        i= (i+1.5).toFloat();
            }

            override fun onFinish() {

            }

        }.start()

    }
}
